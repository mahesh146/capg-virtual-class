export class User{
   
        userId:number;
        userName:string;
      email:string;
      phone:number;
  
} 