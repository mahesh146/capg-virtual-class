import { Component } from '@angular/core';
import { Route } from '@angular/compiler/src/core';
import { Routes, ActivatedRoute, RouterLink, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'user-app';
  constructor(private router:Router){}
  userId:number;
  viewUserComponent(){
    this.router.navigate(["/view-user/"+this.userId]);
  }
  

}

