import { Component, OnInit } from '@angular/core';
import { UserApiService } from '../user-api.service';
import { User } from '../User';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {

  constructor(private userApiService:UserApiService) { }
  public user:User;
  
  ngOnInit(): void {
    
  }
 updateUser(data){
    
  this.userApiService.updateUser(this.user=data.value).subscribe(
    (success)=>{
      alert("User is updated");
    }
    
  )
 }
}
