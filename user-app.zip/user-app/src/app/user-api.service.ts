import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './User';

@Injectable({
  providedIn: 'root'
})
export class UserApiService {

  constructor(private httpClient:HttpClient) { }
private baseUrl="http://localhost:8888/api/";
  public addUser(user:User):Observable<any>{
    return this.httpClient.post(this.baseUrl+"users",user);
  }

  public getUserInfo(userId:number):Observable<any>{
    return this.httpClient.get(this.baseUrl+"users/id/"+userId);
  }

  public deleteUser(userId:number):Observable<any>{
    console.log("Delete User Called for user id : "+userId);
    console.log(this.baseUrl+"users/id/"+userId);
    return this.httpClient.delete(this.baseUrl+"users/id/"+userId);
    
  }
  public updateUser(user:User):Observable<any>{
    return this.httpClient.put(this.baseUrl+"users",user);
  }

}
