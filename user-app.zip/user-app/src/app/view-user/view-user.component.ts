import { Component, OnInit } from '@angular/core';
import { UserApiService } from '../user-api.service';
import { User } from '../User';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {

  constructor(private userApiService:UserApiService,private route:ActivatedRoute,private router:Router) { }
  userId:number;
  ngOnInit(): void {
    this.route.params.subscribe(
      (param)=>{
        this.searchUser(param["id"]);
      }
    )
  }
  public user:User;

deleteUser(){
if(confirm("Sure to Delete?")){
  this.userApiService.deleteUser(this.user.userId).subscribe(
    (success)=>{
  alert("User with id ["+this.user.userId+"] Deleted");
  this.user=null;
    },
    (error)=>{
      alert("Deletion Failed");
    }

  );
}
}
updateUser(){
  this.router.navigate(["/update-user"]);
}


  searchUser(userId:number){
      this.userApiService.getUserInfo(userId).subscribe(
        (user)=>{
          this.user=user;
          console.log(user);
        },
        (error)=>{
          this.user=null;
          alert("User Not Found");
        }
      );
  }



}
